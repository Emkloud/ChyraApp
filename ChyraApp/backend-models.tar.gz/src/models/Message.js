const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  conversation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Conversation',
    required: [true, 'Conversation ID is required'],
    index: true
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Sender ID is required'],
    index: true
  },
  content: {
    type: String,
    trim: true,
    maxlength: [5000, 'Message content cannot exceed 5000 characters']
  },
  type: {
    type: String,
    enum: ['text', 'image', 'video', 'audio', 'file', 'voice', 'location', 'system', 'media_group'],
    default: 'text'
  },
  media: {
    url: String,
    filename: String,
    size: Number,
    mimeType: String,
    thumbnail: String,
    duration: Number,
    width: Number,
    height: Number
  },
  // ✅ NEW: Support for multiple media items (gallery)
  mediaGroup: [{
    type: {
      type: String,
      enum: ['image', 'video', 'audio', 'file']
    },
    url: String,
    filename: String,
    size: Number,
    mimeType: String,
    thumbnail: String,
    duration: Number,
    width: Number,
    height: Number
  }],
  replyTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  },
  reactions: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    emoji: {
      type: String,
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  readBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    readAt: {
      type: Date,
      default: Date.now
    }
  }],
  deliveredTo: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    deliveredAt: {
      type: Date,
      default: Date.now
    }
  }],
  deletedBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    deletedAt: {
      type: Date,
      default: Date.now
    },
    deleteType: {
      type: String,
      enum: ['for_me', 'for_everyone'],
      default: 'for_me'
    }
  }],
  isEdited: {
    type: Boolean,
    default: false
  },
  editedAt: Date,
  editHistory: [{
    content: String,
    editedAt: {
      type: Date,
      default: Date.now
    }
  }],
  isForwarded: {
    type: Boolean,
    default: false
  },
  forwardedFrom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  },
  mentions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  metadata: {
    clientId: String,
    location: {
      latitude: Number,
      longitude: Number,
      address: String
    },
    linkPreview: {
      url: String,
      title: String,
      description: String,
      image: String
    }
  },
  isSystemMessage: {
    type: Boolean,
    default: false
  },
  systemMessageType: {
    type: String,
    enum: ['user_added', 'user_removed', 'group_created', 'group_name_changed', 'group_picture_changed']
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better performance
messageSchema.index({ conversation: 1, createdAt: -1 });
messageSchema.index({ sender: 1, createdAt: -1 });
messageSchema.index({ 'readBy.user': 1 });
messageSchema.index({ 'deliveredTo.user': 1 });
messageSchema.index({ content: 'text' });

// ✅ FIXED: Validate that text messages have content
messageSchema.pre('validate', function(next) {
  if (this.type === 'text' && !this.content && !this.mediaGroup?.length) {
    return next(new Error('Text messages must have content'));
  }
  next();
});

// ✅ FIXED: Initialize arrays if they don't exist
messageSchema.pre('save', function(next) {
  if (!this.reactions) this.reactions = [];
  if (!this.readBy) this.readBy = [];
  if (!this.deliveredTo) this.deliveredTo = [];
  if (!this.deletedBy) this.deletedBy = [];
  if (!this.editHistory) this.editHistory = [];
  if (!this.mentions) this.mentions = [];
  if (!this.mediaGroup) this.mediaGroup = [];
  next();
});

// Method to check if message is read by user
messageSchema.methods.isReadBy = function(userId) {
  if (!this.readBy || !Array.isArray(this.readBy)) return false;
  return this.readBy.some(r => r && r.user && r.user.toString() === userId.toString());
};

// Method to mark as read
messageSchema.methods.markAsRead = function(userId) {
  if (!this.readBy) this.readBy = [];
  if (!this.isReadBy(userId)) {
    this.readBy.push({
      user: userId,
      readAt: Date.now()
    });
  }
};

// Method to check if message is delivered to user
messageSchema.methods.isDeliveredTo = function(userId) {
  if (!this.deliveredTo || !Array.isArray(this.deliveredTo)) return false;
  return this.deliveredTo.some(d => d && d.user && d.user.toString() === userId.toString());
};

// Method to mark as delivered
messageSchema.methods.markAsDelivered = function(userId) {
  if (!this.deliveredTo) this.deliveredTo = [];
  if (!this.isDeliveredTo(userId)) {
    this.deliveredTo.push({
      user: userId,
      deliveredAt: Date.now()
    });
  }
};

// Method to add reaction
messageSchema.methods.addReaction = function(userId, emoji) {
  if (!this.reactions) this.reactions = [];
  
  const existingReaction = this.reactions.find(
    r => r && r.user && r.user.toString() === userId.toString()
  );
  
  if (existingReaction) {
    existingReaction.emoji = emoji;
    existingReaction.createdAt = Date.now();
  } else {
    this.reactions.push({
      user: userId,
      emoji: emoji
    });
  }
};

// Method to remove reaction
messageSchema.methods.removeReaction = function(userId) {
  if (!this.reactions || !Array.isArray(this.reactions)) {
    this.reactions = [];
    return;
  }
  
  this.reactions = this.reactions.filter(
    r => r && r.user && r.user.toString() !== userId.toString()
  );
};

// Method to check if user can delete message
messageSchema.methods.canDelete = function(userId, deleteType = 'for_me') {
  if (deleteType === 'for_everyone') {
    return this.sender && this.sender.toString() === userId.toString();
  }
  return true;
};

// Method to delete message for user
messageSchema.methods.deleteFor = function(userId, deleteType = 'for_me') {
  if (!this.canDelete(userId, deleteType)) {
    throw new Error('You cannot delete this message for everyone');
  }
  
  if (!this.deletedBy) this.deletedBy = [];
  
  this.deletedBy.push({
    user: userId,
    deletedAt: Date.now(),
    deleteType: deleteType
  });
};

// Method to check if message is deleted for user
messageSchema.methods.isDeletedFor = function(userId) {
  if (!this.deletedBy || !Array.isArray(this.deletedBy)) return false;
  return this.deletedBy.some(d => d && d.user && d.user.toString() === userId.toString());
};

// Method to edit message
messageSchema.methods.edit = function(newContent) {
  if (!this.editHistory) this.editHistory = [];
  
  if (this.content) {
    this.editHistory.push({
      content: this.content,
      editedAt: Date.now()
    });
  }
  
  this.content = newContent;
  this.isEdited = true;
  this.editedAt = Date.now();
};

// Static method to get unread count for user in conversation
messageSchema.statics.getUnreadCount = async function(conversationId, userId) {
  try {
    return await this.countDocuments({
      conversation: conversationId,
      sender: { $ne: userId },
      'readBy.user': { $ne: userId },
      'deletedBy.user': { $ne: userId }
    });
  } catch (error) {
    console.error('Error getting unread count:', error);
    return 0;
  }
};

// Static method to get messages for user (excluding deleted)
messageSchema.statics.getForUser = function(query, userId) {
  return this.find({
    ...query,
    'deletedBy.user': { $ne: userId }
  });
};

// ✅ FIXED: Virtual for reaction counts with proper null checks
messageSchema.virtual('reactionCounts').get(function() {
  const counts = {};
  
  // Safety check: ensure reactions exists and is an array
  if (!this.reactions || !Array.isArray(this.reactions)) {
    return counts;
  }
  
  // Iterate through reactions with additional safety checks
  this.reactions.forEach(reaction => {
    if (reaction && reaction.emoji) {
      counts[reaction.emoji] = (counts[reaction.emoji] || 0) + 1;
    }
  });
  
  return counts;
});

const Message = mongoose.model('Message', messageSchema);

module.exports = Message;