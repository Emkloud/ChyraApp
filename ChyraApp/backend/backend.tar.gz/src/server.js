require('dotenv').config();
const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

// Import configurations
const connectDatabase = require('./config/database');
const { RATE_LIMIT, SOCKET_EVENTS } = require('./config/constants');
const logger = require('./utils/logger');

// Import middleware
const { errorHandler, notFound } = require('./middleware/errorHandler');
const { socketAuth } = require('./middleware/auth');

// Import routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const chatRoutes = require('./routes/chats');
const messageRoutes = require('./routes/messages');
const contactRoutes = require('./routes/contacts');
const groupRoutes = require('./routes/groups');
const profileRoutes = require('./routes/profile');
const callRoutes = require('./routes/calls');
const accountRoutes = require('./routes/account');
const uploadRoutes = require('./routes/upload');

// ✅ NEW: Import socket handler
const initializeSocketHandlers = require('./socket/socketHandler');

// Initialize express app
const app = express();
const httpServer = createServer(app);

// Trust first proxy
app.set('trust proxy', 1);

// Initialize Socket.IO
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CORS_ORIGIN?.split(',') || '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000
});

// Connect to database
connectDatabase();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));

// CORS Configuration
const defaultAllowedOrigins = [
  'https://chyraapp.com',
  'https://www.chyraapp.com',
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:5174',
  'http://localhost:4173',
  'http://localhost:8080'
];

const configuredOrigins = process.env.CORS_ORIGIN 
  ? process.env.CORS_ORIGIN.split(',').map(o => o.trim()) 
  : defaultAllowedOrigins;

const isAllowedOrigin = (origin) => {
  if (!origin) {
    logger.info('✓ CORS: Allowing request with no origin');
    return true;
  }

  try {
    const url = new URL(origin);
    const hostname = url.hostname;
    
    if (hostname === 'chyraapp.com' || hostname === 'www.chyraapp.com') {
      logger.info(`✓ CORS: Allowing main domain: ${origin}`);
      return true;
    }
    
    if (hostname.endsWith('.chyraapp.com')) {
      logger.info(`✓ CORS: Allowing subdomain: ${origin}`);
      return true;
    }
    
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      logger.info(`✓ CORS: Allowing localhost: ${origin}`);
      return true;
    }
    
    if (configuredOrigins.includes(origin)) {
      logger.info(`✓ CORS: Allowing configured origin: ${origin}`);
      return true;
    }
    
    logger.warn(`✗ CORS: Blocked origin: ${origin}`);
    return false;
  } catch (e) {
    logger.warn(`✗ CORS: Invalid origin format: ${origin}`);
    return false;
  }
};

app.use(cors({
  origin: (origin, callback) => {
    if (isAllowedOrigin(origin)) {
      callback(null, true);
    } else {
      callback(null, false);
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Content-Range', 'X-Content-Range'],
  maxAge: 86400,
  optionsSuccessStatus: 204
}));

app.options('*', cors());

logger.info('✓ CORS Configuration:');
logger.info('  - Main domains: chyraapp.com, www.chyraapp.com');
logger.info('  - Subdomains: *.chyraapp.com');
logger.info('  - Localhost: All ports');
logger.info('  - Configured origins:', configuredOrigins);

// Body parser & middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(compression());

// Rate limiting
const limiter = rateLimit({
  windowMs: RATE_LIMIT.WINDOW_MS,
  max: RATE_LIMIT.MAX_REQUESTS,
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Make io accessible to routes
app.set('io', io);

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/groups', groupRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/calls', callRoutes);
app.use('/api/account', accountRoutes);
app.use('/api/upload', uploadRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'ChyraApp API is running',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    routes: {
      auth: '/api/auth',
      users: '/api/users',
      chats: '/api/chats',
      messages: '/api/messages',
      contacts: '/api/contacts',
      groups: '/api/groups',
      profile: '/api/profile',
      calls: '/api/calls',
      account: '/api/account'
    }
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Welcome to ChyraApp API',
    version: '1.0.0',
    documentation: '/api/docs',
    health: '/health'
  });
});

// ==========================================
// SOCKET.IO SETUP
// ==========================================

// Socket.IO Authentication
io.use(socketAuth);

// ✅ NEW: Initialize comprehensive socket handlers
const socketUtils = initializeSocketHandlers(io);

// ✅ KEPT: Your existing socket events for backward compatibility
io.on(SOCKET_EVENTS.CONNECTION, (socket) => {
  const userId = socket.userId;
  logger.info(`✅ User connected: ${userId}`);

  socket.join(`user:${userId}`);

  // Handle user online status
  socket.on(SOCKET_EVENTS.USER_ONLINE, async () => {
    try {
      const User = require('./models/User');
      await User.findByIdAndUpdate(userId, {
        isOnline: true,
        socketId: socket.id,
        lastSeen: Date.now()
      });

      socket.broadcast.emit(SOCKET_EVENTS.USER_ONLINE, { userId });
      logger.info(`👤 User ${userId} is now online`);
    } catch (error) {
      logger.error('User online error:', error);
    }
  });

  // Handle user typing
  socket.on(SOCKET_EVENTS.USER_TYPING, ({ conversationId }) => {
    socket.to(`conversation:${conversationId}`).emit(SOCKET_EVENTS.USER_TYPING, {
      userId,
      conversationId
    });
  });

  // Handle user stop typing
  socket.on(SOCKET_EVENTS.USER_STOP_TYPING, ({ conversationId }) => {
    socket.to(`conversation:${conversationId}`).emit(SOCKET_EVENTS.USER_STOP_TYPING, {
      userId,
      conversationId
    });
  });

  // Join conversation room
  socket.on(SOCKET_EVENTS.CONVERSATION_JOIN, ({ conversationId }) => {
    socket.join(`conversation:${conversationId}`);
    logger.info(`🚪 User ${userId} joined conversation ${conversationId}`);
  });

  // Leave conversation room
  socket.on(SOCKET_EVENTS.CONVERSATION_LEAVE, ({ conversationId }) => {
    socket.leave(`conversation:${conversationId}`);
    logger.info(`🚪 User ${userId} left conversation ${conversationId}`);
  });

  // Handle new message
  socket.on(SOCKET_EVENTS.MESSAGE_SEND, async (messageData) => {
    try {
      const conversationId = messageData.conversationId || messageData.conversation;
      
      // Emit to all users in the conversation
      io.to(`conversation:${conversationId}`).emit(
        SOCKET_EVENTS.MESSAGE_RECEIVE,
        {
          ...messageData,
          chat: conversationId,
          conversation: conversationId
        }
      );
      
      logger.info(`📨 Message sent in conversation ${conversationId}`);
    } catch (error) {
      logger.error('Message send error:', error);
      socket.emit(SOCKET_EVENTS.ERROR, { message: 'Failed to send message' });
    }
  });

  // ✅ Handle message read - marks in DB and notifies sender
  socket.on('message:read', async ({ messageId, conversationId }) => {
    try {
      const Message = require('./models/Message');
      const message = await Message.findById(messageId);
      
      if (message && !message.isReadBy(userId)) {
        message.markAsRead(userId);
        await message.save();
        
        // Notify all users in conversation (especially the sender)
        io.to(`conversation:${conversationId}`).emit('message:read', {
          messageId,
          userId,
          conversationId
        });
        
        logger.info(`👁️ Message ${messageId} marked as read by ${userId}`);
      }
    } catch (error) {
      logger.error('Mark message read error:', error);
    }
  });

  // Handle friend request events
  socket.on('friend_request_sent', ({ receiverId, request }) => {
    io.to(`user:${receiverId}`).emit('friend_request_received', request);
    logger.info(`👥 Friend request sent from ${userId} to ${receiverId}`);
  });

  socket.on('friend_request_accepted', ({ senderId, receiverId }) => {
    io.to(`user:${senderId}`).emit('friend_request_accepted', { userId: receiverId });
    io.to(`user:${receiverId}`).emit('friend_added', { userId: senderId });
    logger.info(`✅ Friend request accepted: ${senderId} <-> ${receiverId}`);
  });

  socket.on('friend_request_rejected', ({ senderId }) => {
    io.to(`user:${senderId}`).emit('friend_request_rejected');
    logger.info(`❌ Friend request rejected by ${userId}`);
  });

  // Handle group events
  socket.on('group_created', ({ groupId, members }) => {
    members.forEach(memberId => {
      io.to(`user:${memberId}`).emit('group_created', { groupId });
    });
    logger.info(`👥 Group created: ${groupId}`);
  });

  socket.on('group_message', ({ groupId, message }) => {
    socket.to(`group:${groupId}`).emit('group_message', message);
  });

  socket.on('join_group', ({ groupId }) => {
    socket.join(`group:${groupId}`);
    logger.info(`👥 User ${userId} joined group ${groupId}`);
  });

  socket.on('leave_group', ({ groupId }) => {
    socket.leave(`group:${groupId}`);
    logger.info(`👥 User ${userId} left group ${groupId}`);
  });

  // WebRTC Signaling Events
  socket.on('call:initiate', ({ callId, receiverId, callType, offer }) => {
    logger.info(`📞 Call initiated: ${callId} from ${userId} to ${receiverId} (${callType})`);
    io.to(`user:${receiverId}`).emit('call:incoming', {
      callId,
      callerId: userId,
      callerName: socket.username || 'Unknown',
      callType,
      offer
    });
  });

  socket.on('call:answer', ({ callId, callerId, answer }) => {
    logger.info(`📞 Call answered: ${callId}`);
    io.to(`user:${callerId}`).emit('call:answered', {
      callId,
      answer
    });
  });

  socket.on('call:decline', ({ callId, callerId }) => {
    logger.info(`📞 Call declined: ${callId}`);
    io.to(`user:${callerId}`).emit('call:declined', {
      callId
    });
  });

  socket.on('call:end', ({ callId, otherUserId }) => {
    logger.info(`📞 Call ended: ${callId}`);
    io.to(`user:${otherUserId}`).emit('call:ended', {
      callId
    });
  });

  socket.on('call:ice-candidate', ({ candidate, otherUserId }) => {
    io.to(`user:${otherUserId}`).emit('call:ice-candidate', {
      candidate
    });
  });

  socket.on('call:busy', ({ callId, callerId }) => {
    logger.info(`📞 Call busy: ${callId}`);
    io.to(`user:${callerId}`).emit('call:busy', {
      callId
    });
  });

  socket.on('call:failed', ({ callId, otherUserId, reason }) => {
    logger.info(`📞 Call failed: ${callId}, reason: ${reason}`);
    io.to(`user:${otherUserId}`).emit('call:failed', {
      callId,
      reason
    });
  });

  // Handle disconnect
  socket.on(SOCKET_EVENTS.DISCONNECT, async () => {
    try {
      const User = require('./models/User');
      await User.findByIdAndUpdate(userId, {
        isOnline: false,
        socketId: null,
        lastSeen: Date.now()
      });

      socket.broadcast.emit(SOCKET_EVENTS.USER_OFFLINE, { userId });
      logger.info(`❌ User disconnected: ${userId}`);
    } catch (error) {
      logger.error('Disconnect error:', error);
    }
  });
});

// Error Handlers
app.use(notFound);
app.use(errorHandler);

// Start Server
const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
  logger.info('=================================');
  logger.info(`🚀 ChyraApp Server Running`);
  logger.info(`✓ Server running on port ${PORT}`);
  logger.info(`✓ Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`✓ API: http://localhost:${PORT}`);
  logger.info(`✓ Health: http://localhost:${PORT}/health`);
  logger.info(`✓ Socket.IO: Enabled with comprehensive handlers`);
  logger.info(`✓ Routes loaded:`);
  logger.info(`   - /api/auth`);
  logger.info(`   - /api/users`);
  logger.info(`   - /api/chats`);
  logger.info(`   - /api/messages ✅`);
  logger.info(`   - /api/contacts`);
  logger.info(`   - /api/groups`);
  logger.info(`   - /api/profile`);
  logger.info(`   - /api/calls`);
  logger.info(`   - /api/account`);
  logger.info(`   - /api/upload`);
  logger.info('=================================');
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  logger.error('❌ Unhandled Rejection:', err);
  httpServer.close(() => process.exit(1));
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  logger.error('❌ Uncaught Exception:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('⚠️ SIGTERM received. Closing server gracefully...');
  httpServer.close(() => {
    logger.info('✅ Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('⚠️ SIGINT received. Closing server gracefully...');
  httpServer.close(() => {
    logger.info('✅ Server closed');
    process.exit(0);
  });
});

module.exports = { app, httpServer, io };