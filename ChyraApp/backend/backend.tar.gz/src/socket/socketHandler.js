/**
 * Socket.IO Event Handler
 * Manages real-time WebSocket connections and events
 */

const User = require('../models/User');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');

// Track online users: Map<userId, socketId>
const onlineUsers = new Map();

// Track user's active conversations: Map<socketId, Set<conversationId>>
const userRooms = new Map();

/**
 * Initialize Socket.IO handlers
 * @param {SocketIO.Server} io - Socket.IO server instance
 */
module.exports = (io) => {
  io.on('connection', (socket) => {
    console.log(`✅ Socket connected: ${socket.id}`);

    // ==========================================
    // USER ONLINE/OFFLINE STATUS
    // ==========================================

    socket.on('user:online', async () => {
      try {
        const userId = socket.user?._id?.toString();
        
        if (!userId) {
          console.warn('⚠️ user:online event without authenticated user');
          return;
        }

        console.log(`👤 User online: ${userId}`);

        // Store user's socket connection
        onlineUsers.set(userId, socket.id);
        userRooms.set(socket.id, new Set());

        // Update user's online status in database
        await User.findByIdAndUpdate(userId, {
          isOnline: true,
          lastSeen: new Date()
        });

        // Broadcast to all clients that user is online
        socket.broadcast.emit('user:online', { userId });

        // Send current online users to the connecting user
        const onlineUserIds = Array.from(onlineUsers.keys());
        socket.emit('users:online', onlineUserIds);

      } catch (error) {
        console.error('❌ user:online error:', error);
      }
    });

    socket.on('disconnect', async () => {
      try {
        const userId = socket.user?._id?.toString();
        
        if (!userId) {
          console.log('❌ Socket disconnected:', socket.id);
          return;
        }

        console.log(`❌ User disconnected: ${userId} (${socket.id})`);

        // Remove from online users
        onlineUsers.delete(userId);

        // Leave all rooms
        const rooms = userRooms.get(socket.id);
        if (rooms) {
          rooms.forEach(room => socket.leave(room));
          userRooms.delete(socket.id);
        }

        // Update database
        await User.findByIdAndUpdate(userId, {
          isOnline: false,
          lastSeen: new Date()
        });

        // Broadcast offline status
        socket.broadcast.emit('user:offline', { userId });

      } catch (error) {
        console.error('❌ disconnect error:', error);
      }
    });

    // ==========================================
    // CONVERSATION MANAGEMENT
    // ==========================================

    socket.on('conversation:join', async ({ conversationId }) => {
      try {
        const userId = socket.user?._id?.toString();
        
        if (!userId || !conversationId) {
          console.warn('⚠️ conversation:join missing data');
          return;
        }

        console.log(`🚪 User ${userId} joining conversation: ${conversationId}`);

        // Verify user is participant
        const conversation = await Conversation.findById(conversationId);
        if (!conversation) {
          console.warn('⚠️ Conversation not found:', conversationId);
          return;
        }

        const isParticipant = conversation.participants.some(
          p => p.user.toString() === userId
        );

        if (!isParticipant) {
          console.warn('⚠️ User not participant in conversation:', userId);
          return;
        }

        // Join room
        const roomName = `conversation:${conversationId}`;
        socket.join(roomName);

        // Track room
        const rooms = userRooms.get(socket.id) || new Set();
        rooms.add(roomName);
        userRooms.set(socket.id, rooms);

        console.log(`✅ User ${userId} joined ${roomName}`);

      } catch (error) {
        console.error('❌ conversation:join error:', error);
      }
    });

    socket.on('conversation:leave', ({ conversationId }) => {
      try {
        const roomName = `conversation:${conversationId}`;
        socket.leave(roomName);

        const rooms = userRooms.get(socket.id);
        if (rooms) {
          rooms.delete(roomName);
        }

        console.log(`🚪 User left ${roomName}`);

      } catch (error) {
        console.error('❌ conversation:leave error:', error);
      }
    });

    // ==========================================
    // MESSAGE EVENTS
    // ==========================================

    socket.on('message:send', async (messageData) => {
      try {
        const userId = socket.user?._id?.toString();
        const conversationId = messageData.conversation || messageData.conversationId;

        if (!userId || !conversationId) {
          console.warn('⚠️ message:send missing data');
          return;
        }

        console.log(`📨 Broadcasting message from ${userId} to conversation ${conversationId}`);

        const roomName = `conversation:${conversationId}`;

        // Broadcast to all users in the conversation room EXCEPT sender
        socket.to(roomName).emit('message:receive', {
          ...messageData,
          chat: conversationId,
          conversation: conversationId
        });

        // Send confirmation back to sender
        socket.emit('message:sent', {
          _id: messageData._id,
          success: true
        });

        console.log(`✅ Message broadcasted to ${roomName}`);

      } catch (error) {
        console.error('❌ message:send error:', error);
        socket.emit('message:error', {
          error: error.message
        });
      }
    });

    socket.on('message:read', async ({ messageId, conversationId }) => {
      try {
        const userId = socket.user?._id?.toString();

        if (!userId || !messageId) {
          return;
        }

        console.log(`👁️ Message ${messageId} read by ${userId}`);

        // Update message in database
        const message = await Message.findById(messageId);
        if (message) {
          message.markAsRead(userId);
          await message.save();
        }

        // Broadcast read receipt
        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('message:read', {
          messageId,
          userId,
          conversationId
        });

      } catch (error) {
        console.error('❌ message:read error:', error);
      }
    });

    // ==========================================
    // TYPING INDICATORS
    // ==========================================

    socket.on('user:typing', ({ conversationId }) => {
      try {
        const userId = socket.user?._id?.toString();

        if (!userId || !conversationId) {
          return;
        }

        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('user:typing', {
          userId,
          conversationId
        });

      } catch (error) {
        console.error('❌ user:typing error:', error);
      }
    });

    socket.on('user:stop_typing', ({ conversationId }) => {
      try {
        const userId = socket.user?._id?.toString();

        if (!userId || !conversationId) {
          return;
        }

        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('user:stop_typing', {
          userId,
          conversationId
        });

      } catch (error) {
        console.error('❌ user:stop_typing error:', error);
      }
    });

    // ==========================================
    // MESSAGE REACTIONS
    // ==========================================

    socket.on('message:react', async ({ messageId, conversationId, emoji }) => {
      try {
        const userId = socket.user?._id?.toString();

        if (!userId || !messageId) {
          return;
        }

        console.log(`😊 User ${userId} reacted to message ${messageId} with ${emoji}`);

        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('message:react', {
          messageId,
          userId,
          emoji
        });

      } catch (error) {
        console.error('❌ message:react error:', error);
      }
    });

    // ==========================================
    // MESSAGE EDIT/DELETE
    // ==========================================

    socket.on('message:edit', ({ messageId, conversationId, content }) => {
      try {
        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('message:edit', {
          messageId,
          content,
          isEdited: true,
          editedAt: new Date()
        });

      } catch (error) {
        console.error('❌ message:edit error:', error);
      }
    });

    socket.on('message:delete', ({ messageId, conversationId, deleteType }) => {
      try {
        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit('message:delete', {
          messageId,
          deleteType
        });

      } catch (error) {
        console.error('❌ message:delete error:', error);
      }
    });

    // ==========================================
    // GROUP EVENTS (if applicable)
    // ==========================================

    socket.on('join_group', ({ groupId }) => {
      socket.join(`group:${groupId}`);
      console.log(`👥 Socket ${socket.id} joined group:${groupId}`);
    });

    socket.on('leave_group', ({ groupId }) => {
      socket.leave(`group:${groupId}`);
      console.log(`👥 Socket ${socket.id} left group:${groupId}`);
    });

    socket.on('group_message', (data) => {
      const roomName = `group:${data.groupId}`;
      socket.to(roomName).emit('group_message', data);
    });

    // ==========================================
    // CALL EVENTS (for future WebRTC)
    // ==========================================

    socket.on('call:initiate', ({ to, offer }) => {
      const recipientSocketId = onlineUsers.get(to);
      if (recipientSocketId) {
        io.to(recipientSocketId).emit('call:incoming', {
          from: socket.user._id,
          offer
        });
      }
    });

    socket.on('call:answer', ({ to, answer }) => {
      const callerSocketId = onlineUsers.get(to);
      if (callerSocketId) {
        io.to(callerSocketId).emit('call:answered', {
          from: socket.user._id,
          answer
        });
      }
    });

    socket.on('call:end', ({ to }) => {
      const recipientSocketId = onlineUsers.get(to);
      if (recipientSocketId) {
        io.to(recipientSocketId).emit('call:ended', {
          from: socket.user._id
        });
      }
    });

  });

  // Return utilities for external use
  return {
    getOnlineUsers: () => Array.from(onlineUsers.keys()),
    isUserOnline: (userId) => onlineUsers.has(userId),
    getUserSocketId: (userId) => onlineUsers.get(userId)
  };
};