const express = require('express');
const router = express.Router();
const Group = require('../models/Group');
const { protect } = require('../middleware/auth');
const mongoose = require('mongoose');

// @route   GET /api/groups
// @desc    List groups
// @access  Public (TEMP)
router.get('/', async (req, res) => {
  try {
    const groups = await Group.find({})
      .select('name members createdAt')
      .sort({ createdAt: -1 })
      .limit(100)
      .lean();
    res.json(groups);
  } catch (error) {
    console.error('Get groups error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/groups
// @desc    Create a new group
// @access  Private
router.post('/', protect, async (req, res) => {
  try {
    const { name, description, avatar } = req.body;

    if (!name || name.trim() === '') {
      return res.status(400).json({ message: 'Group name is required' });
    }

    const group = new Group({
      name: name.trim(),
      description: description?.trim() || '',
      avatar: avatar || '👥',
      creator: req.user.id,
      members: [req.user.id],
      admins: [req.user.id],
      lastMessage: {
        content: 'Group created',
        sender: req.user.id,
        createdAt: new Date()
      }
    });

    await group.save();
    
    const populatedGroup = await Group.findById(group._id)
      .populate('creator', 'username email')
      .populate('members', 'username email');

    res.status(201).json(populatedGroup);
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   GET /api/groups/:id
// @desc    Get group by ID
// @access  Public (TEMP)
router.get('/:id', async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid group id' });
    }
    const group = await Group.findById(req.params.id)
      .populate('members', 'username email profilePicture')
      .populate('admins', 'username email profilePicture')
      .populate('creator', 'username email profilePicture')
      .lean();

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    res.json(group);
  } catch (error) {
    console.error('Get group error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// ============================================
// GROUP MESSAGES ENDPOINTS
// ============================================

// @route   GET /api/groups/:id/messages
// @desc    Get messages for a group
// @access  Private
router.get('/:id/messages', protect, async (req, res) => {
  try {
    const Message = require('../models/Message');
    
    console.log(`📥 Loading messages for group: ${req.params.id}`);
    
    const messages = await Message.find({ 
      conversation: req.params.id 
    })
      .populate('sender', 'username email profilePicture')
      .sort({ createdAt: 1 })
      .limit(100);
    
    console.log(`✅ Found ${messages.length} messages`);
    
    res.json({
      success: true,
      data: { messages }
    });
  } catch (error) {
    console.error('❌ Get group messages error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error',
      error: error.message 
    });
  }
});

// @route   POST /api/groups/:id/messages
// @desc    Send message to group
// @access  Private
router.post('/:id/messages', protect, async (req, res) => {
  try {
    const Message = require('../models/Message');
    const { content, type, media } = req.body;
    
    console.log(`📤 Sending message to group: ${req.params.id}`);
    
    const message = await Message.create({
      conversation: req.params.id,
      sender: req.user.id,
      content,
      type: type || 'text',
      media,
      createdAt: new Date()
    });
    
    await message.populate('sender', 'username email profilePicture');
    
    console.log(`✅ Message created: ${message._id}`);
    
    // Emit socket event
    const io = req.app.get('io');
    if (io) {
      io.to(`group:${req.params.id}`).emit('group:message', message);
    }
    
    res.status(201).json({
      success: true,
      data: { message }
    });
  } catch (error) {
    console.error('❌ Send group message error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error',
      error: error.message 
    });
  }
});

// ============================================
// GROUP MANAGEMENT ENDPOINTS
// ============================================

// @route   PUT /api/groups/:id
// @desc    Update group
// @access  Private (Admin only)
router.put('/:id', protect, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    if (!group.admins.some(admin => admin.toString() === req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const { name, description, avatar } = req.body;

    if (name) group.name = name.trim();
    if (description !== undefined) group.description = description.trim();
    if (avatar) group.avatar = avatar;

    await group.save();

    const updatedGroup = await Group.findById(group._id)
      .populate('creator', 'username email')
      .populate('members', 'username email');

    res.json(updatedGroup);
  } catch (error) {
    console.error('Update group error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/groups/:id
// @desc    Delete group
// @access  Private (Creator only)
router.delete('/:id', protect, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    if (group.creator.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Only creator can delete group' });
    }

    await group.deleteOne();

    res.json({ message: 'Group deleted' });
  } catch (error) {
    console.error('Delete group error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/groups/:id/members
// @desc    Add member to group
// @access  Private (Admin only)
router.post('/:id/members', protect, async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    if (!group.admins.some(admin => admin.toString() === req.user.id)) {
      return res.status(403).json({ message: 'Only admins can add members' });
    }

    if (group.members.some(member => member.toString() === userId)) {
      return res.status(400).json({ message: 'User is already a member' });
    }

    group.members.push(userId);
    await group.save();

    const updatedGroup = await Group.findById(group._id)
      .populate('creator', 'username email profilePicture')
      .populate('members', 'username email profilePicture')
      .populate('admins', 'username email profilePicture');

    const io = req.app.get('io');
    if (io) {
      io.to(`user:${userId}`).emit('group:added', updatedGroup);
      io.to(`group:${group._id}`).emit('group:member_added', {
        groupId: group._id,
        userId
      });
    }

    res.json({
      success: true,
      message: 'Member added successfully',
      data: updatedGroup
    });
  } catch (error) {
    console.error('Add member error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// @route   DELETE /api/groups/:id/members/:userId
// @desc    Remove member from group
// @access  Private (Admin or self)
router.delete('/:id/members/:userId', protect, async (req, res) => {
  try {
    const { userId } = req.params;
    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const isAdmin = group.admins.some(admin => admin.toString() === req.user.id);
    const isSelf = userId === req.user.id;

    if (!isAdmin && !isSelf) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    if (userId === group.creator.toString()) {
      return res.status(400).json({ message: 'Cannot remove group creator' });
    }

    group.members = group.members.filter(member => member.toString() !== userId);
    group.admins = group.admins.filter(admin => admin.toString() !== userId);

    await group.save();

    const io = req.app.get('io');
    if (io) {
      io.to(`user:${userId}`).emit('group:removed', { groupId: group._id });
      io.to(`group:${group._id}`).emit('group:member_removed', {
        groupId: group._id,
        userId
      });
    }

    res.json({
      success: true,
      message: 'Member removed successfully'
    });
  } catch (error) {
    console.error('Remove member error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/groups/:id/admins
// @desc    Make member an admin
// @access  Private (Admin only)
router.post('/:id/admins', protect, async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    const group = await Group.findById(req.params.id);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    if (!group.admins.some(admin => admin.toString() === req.user.id)) {
      return res.status(403).json({ message: 'Only admins can promote members' });
    }

    if (!group.members.some(member => member.toString() === userId)) {
      return res.status(400).json({ message: 'User is not a member' });
    }

    if (group.admins.some(admin => admin.toString() === userId)) {
      return res.status(400).json({ message: 'User is already an admin' });
    }

    group.admins.push(userId);
    await group.save();

    const updatedGroup = await Group.findById(group._id)
      .populate('admins', 'username email profilePicture');

    const io = req.app.get('io');
    if (io) {
      io.to(`group:${group._id}`).emit('group:admin_added', {
        groupId: group._id,
        userId
      });
    }

    res.json({
      success: true,
      message: 'Member promoted to admin',
      data: updatedGroup
    });
  } catch (error) {
    console.error('Promote admin error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;