const mongoose = require('mongoose');

const conversationSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    maxlength: [100, 'Conversation name cannot exceed 100 characters']
  },
  isGroup: {
    type: Boolean,
    default: false
  },
  participants: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    role: {
      type: String,
      enum: ['admin', 'member'],
      default: 'member'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    },
    leftAt: Date,
    isActive: {
      type: Boolean,
      default: true
    }
  }],
  lastMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  },
  lastMessageAt: {
    type: Date,
    default: Date.now
  },
  groupPicture: {
    type: String,
    default: ''
  },
  description: {
    type: String,
    maxlength: [500, 'Description cannot exceed 500 characters'],
    default: ''
  },
  settings: {
    onlyAdminsCanMessage: {
      type: Boolean,
      default: false
    },
    onlyAdminsCanAddMembers: {
      type: Boolean,
      default: false
    },
    disappearingMessages: {
      enabled: {
        type: Boolean,
        default: false
      },
      duration: {
        type: Number,
        default: 604800
      }
    }
  },
  mutedBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    mutedUntil: Date
  }],
  pinnedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  archivedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  deletedBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    deletedAt: {
      type: Date,
      default: Date.now
    }
  }],
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better performance
conversationSchema.index({ 'participants.user': 1 });
conversationSchema.index({ lastMessageAt: -1 });
conversationSchema.index({ updatedAt: -1 });
conversationSchema.index({ isGroup: 1, 'participants.user': 1 });

// Virtual for message count
conversationSchema.virtual('messageCount', {
  ref: 'Message',
  localField: '_id',
  foreignField: 'conversation',
  count: true
});

// Virtual for active participants
conversationSchema.virtual('activeParticipants').get(function() {
  return this.participants.filter(p => p.isActive);
});

// ✅ FIXED: Method to check if user is participant (handles populated user objects)
conversationSchema.methods.isParticipant = function(userId) {
  return this.participants.some(p => {
    // Handle both populated (p.user._id) and non-populated (p.user) cases
    const participantId = p.user._id || p.user;
    return participantId.toString() === userId.toString() && p.isActive;
  });
};

// ✅ FIXED: Method to check if user is admin (handles populated user objects)
conversationSchema.methods.isAdmin = function(userId) {
  const participant = this.participants.find(p => {
    // Handle both populated (p.user._id) and non-populated (p.user) cases
    const participantId = p.user._id || p.user;
    return participantId.toString() === userId.toString() && p.isActive;
  });
  return participant && participant.role === 'admin';
};

// Method to add participant
conversationSchema.methods.addParticipant = function(userId, role = 'member') {
  const existingParticipant = this.participants.find(p => {
    const participantId = p.user._id || p.user;
    return participantId.toString() === userId.toString();
  });
  
  if (existingParticipant) {
    if (!existingParticipant.isActive) {
      existingParticipant.isActive = true;
      existingParticipant.joinedAt = Date.now();
      existingParticipant.leftAt = undefined;
    }
  } else {
    this.participants.push({
      user: userId,
      role: role,
      joinedAt: Date.now(),
      isActive: true
    });
  }
};

// Method to remove participant
conversationSchema.methods.removeParticipant = function(userId) {
  const participant = this.participants.find(p => {
    const participantId = p.user._id || p.user;
    return participantId.toString() === userId.toString();
  });
  
  if (participant) {
    participant.isActive = false;
    participant.leftAt = Date.now();
  }
};

// Method to make user admin
conversationSchema.methods.makeAdmin = function(userId) {
  const participant = this.participants.find(p => {
    const participantId = p.user._id || p.user;
    return participantId.toString() === userId.toString() && p.isActive;
  });
  
  if (participant) {
    participant.role = 'admin';
  }
};

// Method to check if conversation is muted for user
conversationSchema.methods.isMutedFor = function(userId) {
  const muted = this.mutedBy.find(
    m => m.user.toString() === userId.toString()
  );
  
  if (!muted) return false;
  if (!muted.mutedUntil) return true;
  
  return new Date() < muted.mutedUntil;
};

// Method to check if conversation is pinned for user
conversationSchema.methods.isPinnedFor = function(userId) {
  return this.pinnedBy.some(
    id => id.toString() === userId.toString()
  );
};

// Method to check if conversation is archived for user
conversationSchema.methods.isArchivedFor = function(userId) {
  return this.archivedBy.some(
    id => id.toString() === userId.toString()
  );
};

// Method to check if conversation is deleted for user
conversationSchema.methods.isDeletedFor = function(userId) {
  return this.deletedBy.some(
    d => d.user.toString() === userId.toString()
  );
};

// Method to get unread count for user
conversationSchema.methods.getUnreadCount = async function(userId) {
  const Message = mongoose.model('Message');
  return await Message.countDocuments({
    conversation: this._id,
    sender: { $ne: userId },
    'readBy.user': { $ne: userId },
    'deletedBy.user': { $ne: userId }
  });
};

// Update lastMessageAt before saving
conversationSchema.pre('save', function(next) {
  if (this.isModified('lastMessage')) {
    this.lastMessageAt = Date.now();
  }
  next();
});

const Conversation = mongoose.model('Conversation', conversationSchema);

module.exports = Conversation;